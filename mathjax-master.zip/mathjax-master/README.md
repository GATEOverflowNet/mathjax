# Q2A Formatter
Question2answer Formatter

This plugin provides an option to add MathJax script, Prettify script and a Preview for CKEditor and enables them by default on all pages.

For editor support please use this <a href="https://github.com/arjunsuresh/ckeditor-Q2A">modified ckeditor</a>.

Download the ckeditor and place inside qa-plugin/wysiwyg-editor folder. Also copy qa-question.js file inside tobecopied folder to qa-content folder replacing the file present there. 


This is a beta code, use it at your own risk on a production environment. 


